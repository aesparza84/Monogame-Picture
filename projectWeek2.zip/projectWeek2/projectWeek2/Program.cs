﻿
using var game = new projectWeek2.Game1();
game.Run();
