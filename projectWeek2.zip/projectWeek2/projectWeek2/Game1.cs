﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace projectWeek2
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        public SpriteFont font;
        public Texture2D pacman;

        int wMax, hMax;

        public Vector2 pacLocation; //declaration
        public Vector2 pacDirection;//declaration
        int pacSpeed;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            TargetElapsedTime = TimeSpan.FromTicks(333333);
            _graphics.PreferredBackBufferHeight = 800;
            _graphics.PreferredBackBufferWidth = 1300;
            
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            font = Content.Load<SpriteFont>("font");
            pacman = Content.Load<Texture2D>("ghost");
            
            pacLocation = new Vector2(100,100);
            pacDirection = new Vector2(1, 0);
            pacSpeed = 1;

            wMax = _graphics.PreferredBackBufferWidth;
            hMax = _graphics.PreferredBackBufferHeight;
        }

        float time;
        protected override void Update(GameTime gameTime)
        {
            time = (float)gameTime.ElapsedGameTime.TotalMilliseconds;
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            updateMovePacman();

            base.Update(gameTime);
        }

        private void updateKeepPacmanScreen()
        {
            updateMovePacman();
            if (pacLocation.X < 0 || pacLocation.X > _graphics.PreferredBackBufferWidth - pacman.Width)
            {
                pacDirection *= -1;
                pacLocation.Y -= 1;
            }
        }

        private void updateMovePacman()
        {
            pacLocation = pacLocation + (pacDirection * pacSpeed * time);
            updateKeepPacmanScreen();
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            _spriteBatch.DrawString(font, $"{pacLocation}", new Vector2(0,0), Color.Aqua);
            _spriteBatch.Draw(pacman, pacLocation, Color.Wheat);
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}