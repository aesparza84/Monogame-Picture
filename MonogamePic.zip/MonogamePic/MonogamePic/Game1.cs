﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogamePic
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont font;
        private SpriteFont font2;
        private Texture2D planet;
        private Texture2D planet2;
        private Texture2D planet3;
        private Texture2D nova;
        private Texture2D rocks;
        private Texture2D stars;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            
            // TODO: use this.Content to load your game content here
            font = Content.Load<SpriteFont>("font");
            font2 = Content.Load<SpriteFont>("fontTwo");
            planet = Content.Load<Texture2D>("planet");
            planet2 = Content.Load<Texture2D>("planetTwo");
            planet3 = Content.Load<Texture2D>("planetThree");
            nova = Content.Load<Texture2D>("nova");
            rocks = Content.Load<Texture2D>("rocks");
            stars = Content.Load<Texture2D>("stars");
            
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            _spriteBatch.Draw(stars, new Vector2(200, 200), Color.DarkOrchid);
            _spriteBatch.Draw(stars, new Vector2(0, 0), Color.DarkOrchid);
            _spriteBatch.Draw(stars, new Vector2(0, 200), Color.DarkOrchid);
            _spriteBatch.Draw(stars, new Vector2(200,0), Color.DarkRed);

            int n = 10;
            for (int i = 0; i < 50; i++)
            {
                _spriteBatch.DrawString(font2, "The Void", new Vector2(1, n), Color.DarkBlue);
                n += 25;
            }
            _spriteBatch.Draw(planet, new Vector2(600,200), Color.White);
            _spriteBatch.Draw(planet2, new Vector2(0,0), Color.White);
            _spriteBatch.Draw(planet3, new Vector2(50,70), Color.White);
            _spriteBatch.Draw(nova, new Vector2(200,270), Color.White);
            
            _spriteBatch.Draw(rocks, new Vector2(580,0), Color.White);
            _spriteBatch.DrawString(font, "Space, woooooh yeah", new Vector2(300,100), Color.DarkCyan);
            _spriteBatch.DrawString(font, "Space, woooooh yeah", new Vector2(301,101), Color.DeepPink);          
            
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}