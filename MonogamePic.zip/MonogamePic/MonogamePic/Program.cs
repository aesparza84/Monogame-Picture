﻿
using var game = new MonogamePic.Game1();
game.Run();
